import numpy as np
import matplotlib.pyplot as plt

x_min,x_max= -2.0,1.0 #real axis 
y_min,y_max= -1.5,1.5 #imaginary axis
#points along the x and y axis
width=800
height= 800
#parameters for the mandelbrot iteration
threshold= 50.0
max_iteration= 200
#creating the grid of complex nos
x,y=np.mgrid[x_min:x_max:complex(0, width), y_min:y_max:complex(0, height)]
c=x+1j*y #combine x and y for forming the complex no 
#it is z0=0
z=np.zeros_like(c,dtype=np.complex128) 
#creating boolean mask
mask=np.ones(c.shape,dtype=bool)
#performing mandelbrot iterations
for n in range(max_iteration):
    #update z
    z[mask] = z[mask]**2 +c[mask]
    #checking if z exceeds the threshold
    mask[np.abs(z) > threshold] = False

#plotting
plt.imshow(mask.T, extent=[-2,1,-1.5,1.5])
plt.gray()
plt.title("Mandelbrot Plot")
plt.xlabel("Real")
plt.ylabel("Imaginary")
#saving the image
plt.savefig('mandelbrot.png')
plt.show()

