import numpy as np
#building the random 5x5 matrix
P=np.random.rand(5, 5)
P=P/P.sum(axis=1, keepdims=True)## row-stochastic
#building the random probability vector p of n =5 
p=np.random.rand(5)
p=p / p.sum()# # sum_i p[i] = 1
#applying the  transition rule p <- P^T p exactly 50 times to get p50
for _ in range(50):
    p=np.dot(P.T, p)
p50=p
# evaluating the stationary distribution as the eigenvector of P^T for eigenvalue 1
eigenvalues,eigenvectors=np.linalg.eig(P.T)
index=np.argmin(np.abs(eigenvalues - 1))#taking eigen that  is closet to 1
v=np.real(eigenvectors[:,index])
#normalizing the eigen vector
v=v/np.sum(v)
#comparing the component-wise difference between p50 and the stationary distribution
difference=np.abs(p50 - v)
print("Task 1")
print("Matrix P:\n", P)
print("\n50 transitions (p50):\n", p50)
print("\nStationary distribution (v):\n", v)
print("\nComponent-wise difference:\n", difference)
print("\ncomponent-wise difference between p50 and the stationary distribution  Do they match within 10−5 ? ", np.all(difference < 1e-5))
