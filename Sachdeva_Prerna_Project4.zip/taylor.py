import time
import math
import pandas as pd
import sympy as sp
import matplotlib.pyplot as plt
import numpy as np


def taylor_approx(func, start, end, degree, fixed_c, num_points=100):
    x = sp.symbols('x')
    f_expr = func(x)
    #Computing  the Taylor coefficients: f^(n)(c)/n!
    coeffs = []
    for n in range(degree + 1):
        dn = sp.diff(f_expr, x, n).subs(x, fixed_c)
        coeffs.append(float(dn) / math.factorial(n))
    #grid of x-values across the interval
    xs = np.linspace(start, end, num_points)
    approx = np.zeros_like(xs, dtype=float)#empty array to store approximations
    #the Taylor polynomial
    for n, a in enumerate(coeffs):
        approx += a * (xs - fixed_c) ** n
    #Computing true function values for comparison
    f_num = sp.lambdify(x, f_expr, 'numpy')
    true_vals = f_num(xs)
    return xs, approx, true_vals

def taylor_sweep(func, start, end, initial_degree, final_degree, degree_step, fixed_c, num_points=100):
    x = sp.symbols('x') #symbolic variable
    f_expr = func(x) #symbolic expression
    f_num = sp.lambdify(x, f_expr, 'numpy') #converting symbolic to numerical 
    xs = np.linspace(start, end, num_points)
    true_vals = f_num(xs) #computing actual values
    rows = [] # to store result for each degree
    for m in range(initial_degree, final_degree + 1, degree_step): ## Loop through  degrees
        t0 = time.perf_counter() #starting timer
        coeffs = []
        for n in range(m + 1):
            dn = sp.diff(f_expr, x, n).subs(x, fixed_c)
            coeffs.append(float(dn) / math.factorial(n))
        ## Initializing empty array to build the approximation
        approx = np.zeros_like(xs, dtype=float)
        #the Taylor polynomial
        for n, a in enumerate(coeffs):
            approx += a * (xs - fixed_c) ** n
        #stop the timer
        elapsed = time.perf_counter() - t0
        #calculating the total absolute error
        abs_err_sum = float(np.sum(np.abs(true_vals - approx)))
        rows.append({"degree": m, "abs_error_sum": abs_err_sum, "runtime_sec": elapsed})
    ## Converting all stored results to a Pandas DataFrame
    df = pd.DataFrame(rows)
    df.to_csv("taylor_values.csv", index=False)
    return df

if __name__ == "__main__":
    #the target function f(x) = x*sin²(x) + cos(x)
    def f(sym_x):
        return sym_x * sp.sin(sym_x) ** 2 + sp.cos(sym_x)

    xs, approx, true_vals = taylor_approx(
        func=f,
        start=-10,
        end=10,
        degree=99,
        fixed_c=0,
        num_points=100
    )
    print("Task-3")
    print("NumPy array of points approximating f in the interval (start, end):")
    print(xs)

    print("\nThe approximation you computed (Taylor series values):")
    print(approx)

    plt.figure(figsize=(7, 4.5), dpi=140)
    plt.plot(xs, approx, linestyle='-', label='Taylor Approximation (m=99)')
    plt.plot(xs, true_vals, linestyle='--', marker='o', markersize=3, label='Actual')
    plt.xlabel('x')
    plt.ylabel('f(x) = x·sin²(x) + cos(x)')
    plt.legend()
    plt.tight_layout()
    plt.savefig("taylor_plot.png")
    plt.show()
    #Taylor approximation for degrees 60, 70, ,,,100 and records error and runtime
    df = taylor_sweep(
        func=f,
        start=-10,
        end=10,
        initial_degree=50,
        final_degree=100,
        degree_step=10,
        fixed_c=0,
        num_points=100
    )
    print("Saved CSV: taylor values.csv")
    print(df)
